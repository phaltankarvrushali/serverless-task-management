# serverless-task-management
Serverless task management using Lambda and DynamoDB
